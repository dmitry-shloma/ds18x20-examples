#ifndef CONFIG_H_
#define CONFIG_H_


#define F_CPU              8000000UL
#define ONE_WIRE_PORT      PORTD
#define ONE_WIRE_DDR       DDRD
#define ONE_WIRE_PIN       PIND

#endif /* CONFIG_H_ */